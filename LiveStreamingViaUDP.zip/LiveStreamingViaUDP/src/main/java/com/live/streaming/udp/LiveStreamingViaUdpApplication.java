package com.live.streaming.udp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveStreamingViaUdpApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiveStreamingViaUdpApplication.class, args);
	}

}
