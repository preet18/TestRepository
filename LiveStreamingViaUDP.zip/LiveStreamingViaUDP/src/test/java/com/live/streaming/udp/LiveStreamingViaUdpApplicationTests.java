package com.live.streaming.udp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiveStreamingViaUdpApplicationTests {

	@Test
	void contextLoads() {
	}

}
